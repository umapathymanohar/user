<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the Closure to execute when that URI is requested.
|
*/

Route::get('/', function()
{
	return View::make('home.index');
});

Route::get('resetPassword', function()
{
	return View::make('emails.auth.reminder');
});

Route::get('home', 'HomeController@index');
Route::post('user/authenticate', 'UserController@authenticate');

Route::get('forgotPassword', 'UserController@forgotPassword');

Route::get('timesheet', 'TimesheetController@index');
Route::post('timesheet/checkin', 'TimesheetController@checkin');
Route::post('timesheet/checkout', 'TimesheetController@checkout');
Route::get('user/logout', 'UserController@logout');
Route::get('dashboard', 'DashboardController@index');

Route::post('password/remind', function()
{
	$credentials = array('email' => Input::get('email'));

    return Password::remind($credentials);
});