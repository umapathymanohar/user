@extends('layouts.master')

@section('navigation')
@parent
<li><a href="about">About</a></li>
@stop

@section('content')
 

     <div class="row ">
        <div class="span12">
             
 
 <h1>Welcome <em>User</em></h1>

        
 
     </div>
    </div>
    
 
 
@stop