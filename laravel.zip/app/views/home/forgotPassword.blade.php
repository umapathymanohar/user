@extends('layouts.master')

@section('navigation')
@parent
<li><a href="about">About</a></li>
@stop

@section('content')
 

     <div class="row ">
        <div class="offset4 span3">
             
 
  <form class="well" method="post" action="password/remind">
                <legend>Forgot Password</legend>
                <label for="email">Email</label>
                <input type="email" placeholder="Your Email Address" name="email" id="email" />
                

                <hr>
                <button type="submit" class="btn btn-success">Send Mail</button>
    
    
                
            </form>

        
 @if (Session::has('error'))
    {{ trans(Session::get('reason')) }}
@endif
     </div>
    </div>
    
 
 
@stop