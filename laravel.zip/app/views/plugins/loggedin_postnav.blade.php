<div class="btn-group pull-right">
	<a type="button" href="user/logout" class="btn btn-primary" ><i class="icon-off icon-white"></i> Logout</a>
</div>