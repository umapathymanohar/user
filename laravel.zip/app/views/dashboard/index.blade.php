@extends('layouts.master')

@section('navigation')
@parent
<li><a href="about">About</a></li>
@stop

@section('content')
 

     <div class="row ">
        <div class="span12">
             
 
 <h1>Welcome <em>{{ $role }}</em></h1>
 <p><a href="timesheet">Timesheet</a></p>

        
 
     </div>
    </div>
    
 
 
@stop