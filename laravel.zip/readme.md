## Laravel 4.x

### A Framework For Web Artisans

[Official Documentation](http://four.laravel.com) (Under Active Development)

### Contributing To Laravel

**All issues and pull requests should be filed on the [laravel/framework](http://github.com/laravel/framework) repository.**

### License

The Laravel framework is open-sourced software licensed under the [MIT license](http://opensource.org/licenses/MIT)